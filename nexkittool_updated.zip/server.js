require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');
const rateLimit = require('express-rate-limit');
const compression = require('compression');

const app = express();
const PORT = process.env.PORT || 3000;

// Security & Performance
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(compression());
app.use(morgan('dev'));
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ extended: true, limit: '100mb' }));

// Rate Limiters
const apiLimiter = rateLimit({ windowMs: 15*60*1000, max: 200, standardHeaders: true });
const freeLimiter = rateLimit({
  windowMs: 60*60*1000, max: 30,
  message: { error: 'Free tier: 30 AI requests/hour. Upgrade to Pro for unlimited!' },
  skip: (req) => req.headers['x-pro-user'] === process.env.PRO_SECRET
});

// Static files
app.use(express.static(path.join(__dirname, '.'), {
  maxAge: '1d',
  etag: true,
  setHeaders: (res, path) => {
    if (path.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
  }
}));

// API Routes
app.use('/api/image', apiLimiter, require('./backend/routes/image'));
app.use('/api/pdf', apiLimiter, require('./backend/routes/pdf'));
app.use('/api/ai', freeLimiter, require('./backend/routes/ai'));
app.use('/api/payment', require('./backend/routes/payment'));
app.use('/api/utility', apiLimiter, require('./backend/routes/utility'));
app.use('/api/auth', require('./backend/routes/auth'));
app.use('/api/blog', apiLimiter, require('./backend/routes/blog'));

// Health check
app.get('/api/health', (req, res) => res.json({
  status: 'ok', name: 'nexkittool', version: '2.0.0', timestamp: new Date()
}));

// Sitemap & Robots served from root
app.get('/sitemap.xml', (req, res) => res.sendFile(path.join(__dirname, 'sitemap.xml')));
app.get('/sitemap-blog.xml', (req, res) => res.sendFile(path.join(__dirname, 'sitemap-blog.xml')));
app.get('/sitemap-lang.xml', (req, res) => res.sendFile(path.join(__dirname, 'sitemap-lang.xml')));
app.get('/sitemap-index.xml', (req, res) => res.sendFile(path.join(__dirname, 'sitemap-index.xml')));
app.get('/robots.txt', (req, res) => res.sendFile(path.join(__dirname, 'robots.txt')));

// Redirect old /tools/:slug/ paths to the new root-level clean URLs /:slug/
app.get(['/tools/:slug', '/tools/:slug/'], (req, res) => {
  return res.redirect(301, '/' + req.params.slug + '/');
});

const toolSlugs = [
  'image-to-pdf', 'pdf-to-word', 'pdf-to-jpg', 'jpg-to-pdf', 'merge-pdf', 'split-pdf', 'compress-pdf', 'word-to-pdf',
  'grammar-checker', 'ai-essay-writer', 'paraphrase-tool', 'ai-humanizer', 'plagiarism-checker', 'language-translator',
  'text-summarizer', 'background-remover', 'image-compressor', 'image-converter', 'image-resizer', 'qr-code-generator',
  'password-generator', 'word-counter', 'article-rewriter', 'hashtag-generator', 'add-watermark', 'black-white-filter',
  'flip-rotate-image', 'image-cropper', 'pdf-watermark', 'base64-encoder', 'json-formatter', 'lorem-ipsum',
  'url-encoder', 'case-converter', 'color-picker', 'gradient-maker', 'contrast-checker', 'ai-palette-generator'
];

app.get(['/:slug', '/compare/:slug', '/lang/:slug'], (req, res, next) => {
  const slug = req.params.slug;
  if ((toolSlugs.includes(slug) || req.path.startsWith('/compare/') || req.path.startsWith('/lang/')) && !req.path.endsWith('/')) {
    return res.redirect(301, req.path + '/');
  }
  next();
});


// SPA fallback
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

// Error handler
app.use((err, req, res, next) => {
  console.error('Error:', err.message);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

app.listen(PORT, () => console.log(`🚀 Nexkittool running at http://localhost:${PORT}`));
module.exports = app;
